# The Book of Ruby - http://www.sapphiresteel.com

for i in (1..10) do
	puts( i )
end