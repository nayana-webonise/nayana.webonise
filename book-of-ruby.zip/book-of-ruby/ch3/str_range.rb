# The Book of Ruby - http://www.sapphiresteel.com

str_range = ('abc'..'def')
puts( str_range.to_a )
puts( (str_range.to_a).length )
