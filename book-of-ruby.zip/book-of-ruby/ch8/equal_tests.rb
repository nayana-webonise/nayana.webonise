# The Book of Ruby - http://www.sapphiresteel.com
ob1 = Object.new
ob2 = Object.new

puts( ob1==ob2 )
puts( ob1.equal?(ob2) )

puts

s1 = "hello"
s2 = "hello"
puts( s1==s2 )
puts( s1.equal?(s2) )


