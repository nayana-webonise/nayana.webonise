# The Book of Ruby - http://www.sapphiresteel.com

puts( 10.object_id )
x = 10
puts( x.object_id )
x = 10
puts( x.object_id )

puts( 100.object_id )
x = 100
puts( x.object_id )
x = 100
puts( x.object_id )

puts( 10.5.object_id )
x = 10.5
puts( x.object_id )
x = 10.5
puts( x.object_id )
