# The Book of Ruby - http://www.sapphiresteel.com

puts( :ten.object_id )
puts( :ten.object_id )
puts( :ten.object_id )

puts( 10.object_id )
puts( 10.object_id )
puts( 10.object_id )