def showname
   return "Fred"
end
  
puts "Hello #{showname}"
puts( "\n\t#{(1+2) * 3}\nGoodbye" )