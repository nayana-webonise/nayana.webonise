# The Book of Ruby - http://www.sapphiresteel.com

puts( eval("1 + 2" ) )
puts( "#{1 + 2}" )
