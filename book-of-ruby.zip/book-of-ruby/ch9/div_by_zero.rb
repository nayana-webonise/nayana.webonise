# The Book of Ruby - http://www.sapphiresteel.com

x = 1/0
puts( x )