MyConst = 1

if @a == nil then
	@a = 1
else
	@a += MyConst
end

puts @a