# The Book of Ruby - http://www.sapphiresteel.com

puts( Math.sqrt(144) )
puts( Math::PI )
