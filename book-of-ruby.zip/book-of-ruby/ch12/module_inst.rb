# The Book of Ruby - http://www.sapphiresteel.com

module MyMod
end

puts( MyMod.class )